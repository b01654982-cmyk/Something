# Chronoverse deployment

Chronoverse is deployed as a Flask container. The production image installs `requirements.txt`, starts the application with Gunicorn, listens on the platform-provided `PORT` (default 3000), and exposes the unauthenticated readiness endpoint `/api/health`.

The optional `OPENAI_API_KEY`, `YOUTUBE_API_KEY` and `VIDEO_PROVIDER_URL` values are runtime secrets and must be configured through Webdev secret input. They are not copied into the image or browser bundle. If they are absent, Chronoverse keeps its educational and source-aware fallbacks.
