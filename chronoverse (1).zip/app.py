"""Chronoverse Flask application."""
from __future__ import annotations

import json
import os
import re
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request, send_from_directory

from services.ai_service import AIService
from services.history_service import get_context
from services.media_service import MediaService
from services.time_engine import ATLAS_DESTINATIONS, is_journey_request, resolve_destination
from services.video_service import VideoGenerationService

BASE_DIR = Path(__file__).resolve().parent


def create_app(test_config: dict[str, Any] | None = None) -> Flask:
    app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))
    app.config.from_mapping(MAX_CONTENT_LENGTH=64 * 1024, JSON_SORT_KEYS=False, CHRONOS_RATE_LIMIT=int(os.getenv("CHRONOS_RATE_LIMIT", "30")), IMAGE_RATE_LIMIT=int(os.getenv("IMAGE_RATE_LIMIT", "4")))
    if test_config:
        app.config.update(test_config)
    ai = AIService(BASE_DIR / "data" / "generated")
    media = MediaService()
    video = VideoGenerationService()
    buckets: dict[tuple[str, str], deque[float]] = defaultdict(deque)

    def limited(kind: str, limit: int) -> bool:
        now = time.time()
        key = (request.remote_addr or "unknown", kind)
        bucket = buckets[key]
        while bucket and now - bucket[0] > 60:
            bucket.popleft()
        if len(bucket) >= limit:
            return True
        bucket.append(now)
        return False

    def json_body() -> dict[str, Any]:
        body = request.get_json(silent=True)
        return body if isinstance(body, dict) else {}

    @app.get("/")
    def index():
        return render_template("index.html", atlas_entries=ATLAS_DESTINATIONS)

    @app.get("/api/health")
    def health():
        return jsonify({"ok": True, "service": "chronoverse", "ai_text": ai.text_available, "ai_image": ai.image_available, "video_provider": bool(media.youtube_key), "ai_video": video.status()})

    @app.get("/manus-routes.json")
    def route_manifest():
        return jsonify({"routes": [{"path": "/", "title": "Chronoverse — AI Time Travel Museum"}]})

    @app.get("/generated/<path:filename>")
    def generated(filename: str):
        if not re.fullmatch(r"[a-f0-9]{24}\.png", filename):
            return jsonify({"error": "invalid media path"}), 400
        return send_from_directory(BASE_DIR / "data" / "generated", filename, max_age=86400)

    @app.post("/api/chronos")
    def chronos():
        if limited("chronos", app.config["CHRONOS_RATE_LIMIT"]):
            return jsonify({"error": "rate_limited", "message": "CHRONOS is receiving many journeys. Please wait a moment."}), 429
        body = json_body()
        message = str(body.get("message", "")).strip()
        if not message or len(message) > 2000:
            return jsonify({"error": "invalid_message", "message": "Enter a message between 1 and 2000 characters."}), 400
        previous = body.get("destination") if isinstance(body.get("destination"), dict) else None
        destination = resolve_destination(message, previous)
        destination_dict = destination.to_dict()
        answer = ai.ask_chronos(message, destination_dict, body.get("conversation") if isinstance(body.get("conversation"), list) else [])
        context = get_context(destination_dict)
        journey = is_journey_request(message) or not previous or previous.get("key") != destination_dict.get("key")
        return jsonify({"ok": True, "destination": destination_dict, "answer": answer, "context": context, "journey": journey, "should_generate_image": bool(body.get("auto_image", True)) and journey, "provider": {"text": "openai" if answer.get("mode") == "ai" else "offline educational mode", "image": "gpt-image-1" if ai.image_available else "not configured"}})

    @app.post("/api/chronos/image")
    def chronos_image():
        if limited("image", app.config["IMAGE_RATE_LIMIT"]):
            return jsonify({"ok": False, "status": "rate_limited", "reason": "Image generation limit reached for this minute."}), 429
        body = json_body()
        destination = body.get("destination")
        if not isinstance(destination, dict) or not destination.get("key"):
            return jsonify({"ok": False, "status": "invalid_destination", "reason": "A resolved destination is required."}), 400
        scene = str(body.get("scene", "arrival panorama")).strip()[:240] or "arrival panorama"
        result = ai.generate_image(destination, scene)
        if result.get("offline"):
            archive_item = media.featured_commons_image(destination)
            if archive_item:
                return jsonify({"ok": True, "status": "authentic_archive", "cached": False, "archive": True, "image_url": archive_item["preview"], "label": "AUTHENTIC ARCHIVE IMAGE — WIKIMEDIA COMMONS", "source_url": archive_item["original"], "source": archive_item["source"], "title": archive_item["title"]})
        return jsonify(result)

    @app.post("/api/media")
    def historical_media():
        body = json_body()
        destination = body.get("destination")
        if not isinstance(destination, dict) or not destination.get("location"):
            return jsonify({"error": "invalid_destination", "message": "Choose a destination first."}), 400
        category = str(body.get("category", "historical media"))[:120]
        return jsonify(media.search_commons(destination, category))

    @app.post("/api/videos")
    def historical_videos():
        body = json_body()
        destination = body.get("destination")
        if not isinstance(destination, dict) or not destination.get("location"):
            return jsonify({"error": "invalid_destination", "message": "Choose a destination first."}), 400
        return jsonify(media.search_videos(destination))

    @app.post("/api/videos/generate")
    def generate_video():
        body = json_body()
        destination = body.get("destination")
        if not isinstance(destination, dict) or not destination.get("location"):
            return jsonify({"error": "invalid_destination", "message": "Choose a destination first."}), 400
        scene = str(body.get("scene", "cinematic historical scene"))[:240]
        return jsonify(video.generate(destination, scene))

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.getenv("PORT", "3000"))
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=port, debug=os.getenv("FLASK_DEBUG", "0") == "1")
