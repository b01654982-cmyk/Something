# Chronoverse delivery TODO

## Ancient-world atlas expansion
- [x] Homepage includes an original artistic ancient-world atlas visual and 20 curated region/civilization journeys with one-click prompts; copy explicitly explains that modern borders do not map neatly onto ancient states and labels the image as a reconstruction, not an authentic historical photograph. Verified in Chrome preview screenshot and atlas-resolution check.
- [x] Offline image fallback returns a local, destination-themed artistic reconstruction when OpenAI is unconfigured, unavailable or out of credits; nine bundled scenes are served without external image calls and carry a non-authentic-photo label.

## Journey and CHRONOS assistant
- [ ] Visitor can enter a natural-language location, period, year, BCE/CE date, prehistoric period, civilization or future scenario.
- [ ] CHRONOS preserves the current destination in the browser conversation and supports follow-up questions without requiring the destination to be repeated.
- [ ] Responses distinguish verified facts, archaeological evidence, historical estimates, AI reconstructions and speculative futures.
- [ ] Destination arrival includes introduction, countdown, transition, period metadata and exploration suggestions.

## AI reconstruction
- [ ] Automatic generation setting is visible and explains that generation can consume API credits.
- [ ] `gpt-image-1` is called only from the backend when credentials exist; response validation, loading, retry, cache and duplicate-request prevention are implemented.
- [ ] Every generated image is labelled `AI-GENERATED RECONSTRUCTION — NOT AN AUTHENTIC HISTORICAL PHOTOGRAPH.`
- [ ] Missing credentials produce a clear unavailable state rather than a fake image.

## Optional AI video generation
- [ ] AI video generation remains clearly unavailable until an official backend provider and asynchronous job contract are configured; the UI must never display a fabricated video.

## Authentic historical media and videos
- [ ] Historical media explorer uses legitimate API results and renders preview, title, period/location, source, original link, creator and license where available.
- [ ] Missing media API does not create fabricated sources or broken images.
- [ ] Optional YouTube Data API is backend-only; without it, a destination-specific search fallback is provided and videos do not autoplay.

## Gallery, quality and security
- [ ] Destination-specific gallery has separate AI, authentic, documentary and architecture categories with loading, empty, error and responsive states.
- [ ] API credentials are backend-only; request size, input, timeout, media URL and generation rate limits are handled.
- [ ] Existing automated tests are preserved/extended; external calls are mocked and real image/video generation is never used in tests.
- [ ] Homepage, Flask routes, JavaScript syntax and Chrome preview are checked before delivery.
