import base64
import json
import urllib.error
from email.message import Message
from pathlib import Path
from unittest.mock import patch

from app import create_app
from services.ai_service import AIService
from services.time_engine import resolve_destination


def make_client(tmp_path: Path):
    app = create_app({"TESTING": True, "WTF_CSRF_ENABLED": False, "CHRONOS_RATE_LIMIT": 100, "IMAGE_RATE_LIMIT": 100})
    app.config["AI_CACHE_DIR"] = tmp_path
    return app.test_client()


def test_destination_parser_understands_bce_and_known_place():
    destination = resolve_destination("Take me to Rome in 117 CE.")
    assert destination.location == "Rome"
    assert destination.year == 117
    assert destination.year_label == "117 CE"
    assert destination.kind == "historical"

    pyramid = resolve_destination("Show me Egypt during the construction of the Great Pyramid.")
    assert pyramid.location == "Giza, Egypt"
    assert pyramid.year == -2560
    assert "BCE" in pyramid.year_label

    persia = resolve_destination("Take me to Persia in 500 BCE.")
    assert persia.location == "Iran"
    assert persia.year_label == "500 BCE"
    assert "Achaemenid" in persia.era


def test_chronos_route_returns_context_and_preserves_follow_up():
    client = make_client(Path("/tmp/chronoverse-test"))
    first = client.post("/api/chronos", json={"message": "Take me to Ancient Rome in 117 CE.", "auto_image": False})
    assert first.status_code == 200
    payload = first.get_json()
    assert payload["destination"]["location"] == "Rome"
    assert payload["journey"] is True
    assert payload["context"]["cards"]

    follow_up = client.post("/api/chronos", json={"message": "What did ordinary people eat?", "destination": payload["destination"], "conversation": [{"role": "user", "content": first.get_json()["answer"]["reply"]}], "auto_image": False})
    assert follow_up.status_code == 200
    assert follow_up.get_json()["destination"]["key"] == payload["destination"]["key"]
    assert follow_up.get_json()["journey"] is False


def test_invalid_message_and_image_destination_are_rejected():
    client = make_client(Path("/tmp/chronoverse-test"))
    assert client.post("/api/chronos", json={"message": ""}).status_code == 400
    assert client.post("/api/chronos/image", json={}).status_code == 400


def test_image_without_credentials_never_returns_fake_media(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    service = AIService(tmp_path)
    result = service.generate_image({"key": "rome-117", "title": "Ancient Rome"})
    assert result["ok"] is True
    assert result["status"] == "offline_ready"
    assert result["offline"] is True
    assert result["image_url"] == "/static/offline/rome.svg"
    assert not list(tmp_path.glob("*.png"))


def test_chronos_provider_error_is_safe_and_classified(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    service = AIService(tmp_path)
    error = urllib.error.HTTPError("https://api.openai.com/v1/chat/completions", 429, "Too Many Requests", Message(), None)
    with patch.object(service, "_remote_chat", side_effect=error):
        result = service.ask_chronos("Take me to Rome.", {"title": "Rome", "kind": "historical"})
    assert result["mode"] == "offline"
    assert result["provider_error"] == {"category": "quota_or_rate_limit", "status": 429}


def test_image_quota_failure_uses_local_fallback(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    service = AIService(tmp_path)
    error = urllib.error.HTTPError("https://api.openai.com/v1/images/generations", 429, "Too Many Requests", Message(), None)
    with patch("services.ai_service.urllib.request.urlopen", side_effect=error):
        result = service.generate_image({"key": "rome-117", "title": "Ancient Rome"})
    assert result["ok"] is True
    assert result["offline"] is True
    assert result["image_url"].endswith("/static/offline/rome.svg")


def test_image_route_prefers_authentic_archive_photo(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    archive = {"preview": "https://upload.wikimedia.org/commons/rome-ruins.jpg", "original": "https://commons.wikimedia.org/wiki/File:rome-ruins.jpg", "source": "Wikimedia Commons", "title": "Roman ruins"}
    with patch("app.MediaService.featured_commons_image", return_value=archive):
        client = create_app({"TESTING": True}).test_client()
        response = client.post("/api/chronos/image", json={"destination": {"key": "rome-117", "title": "Ancient Rome", "location": "Rome"}})
    payload = response.get_json()
    assert payload["status"] == "authentic_archive"
    assert payload["archive"] is True
    assert payload["image_url"].endswith("rome-ruins.jpg")


def test_image_cache_uses_valid_cached_png(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    service = AIService(tmp_path)
    cache_key = "a" * 24
    # The service derives a key; mock the hash so the fixture remains deterministic.
    with patch("services.ai_service.hashlib.sha256") as digest:
        digest.return_value.hexdigest.return_value = cache_key
        (tmp_path / f"{cache_key}.png").write_bytes(b"\x89PNG" + b"0" * 600)
        result = service.generate_image({"key": "rome-117", "title": "Ancient Rome"})
    assert result["ok"] is True
    assert result["cached"] is True
    assert result["image_url"].endswith(f"{cache_key}.png")


def test_manifest_and_health_are_available():
    client = make_client(Path("/tmp/chronoverse-test"))
    assert client.get("/manus-routes.json").get_json()["routes"][0]["path"] == "/"
    assert client.get("/api/health").get_json()["ok"] is True


def test_video_generation_fails_closed_without_provider():
    client = make_client(Path("/tmp/chronoverse-test"))
    response = client.post("/api/videos/generate", json={"destination": {"location": "Rome"}, "scene": "market"})
    assert response.status_code == 200
    assert response.get_json()["status"] == "unavailable"
    assert "No fake video" in response.get_json()["message"]
