"""Educational context cards for destination dossiers."""
from __future__ import annotations

from typing import Any


BASE_CARDS = [
    ("Evidence mode", "The dossier separates documented facts from interpretation and visual reconstruction.", "method"),
    ("Architecture", "Street-level details are reconstructed from surviving structures, archaeology and period comparisons; some layouts remain uncertain.", "interpretation"),
    ("Daily life", "Everyday experience varied by wealth, gender, status, occupation and geography. A single cinematic scene cannot represent everyone.", "context"),
]

DESTINATION_CARDS: dict[str, list[tuple[str, str, str]]] = {
    "rome": [
        ("Urban systems", "Rome connected monumental public spaces, markets, baths, housing and roads across a dense imperial city.", "documented"),
        ("Technology", "Concrete, arches, aqueducts and road engineering are supported by surviving structures and material evidence.", "archaeology"),
        ("Uncertainty", "Population counts, noise levels and the exact appearance of many lost interiors are estimates rather than direct observations.", "estimate"),
    ],
    "egypt": [
        ("Construction", "The pyramid complex is documented archaeologically; the exact combination of ramps, labor organization and lifting methods remains debated.", "archaeology"),
        ("Landscape", "The Nile floodplain and limestone plateau shaped transport, agriculture and settlement patterns.", "documented"),
        ("Workers", "Evidence from settlements and burials informs a more nuanced picture than the outdated idea of a single undifferentiated slave workforce.", "interpretation"),
    ],
    "samarkand": [
        ("Exchange", "Samarkand’s position connected Central Asian, Persian, Chinese and later Islamic cultural networks, but the exact mix changed over time.", "documented"),
        ("Materials", "Ceramics, textiles, metalwork and manuscript traditions help reconstruct craft and trade economies.", "archaeology"),
        ("Street scene", "A visual market reconstruction is interpretive: surviving evidence rarely preserves a complete everyday street view.", "interpretation"),
    ],
    "baghdad": [
        ("Scholarship", "Abbasid Baghdad supported translation, mathematics, astronomy, medicine and literary exchange across multiple languages.", "documented"),
        ("City form", "Accounts describe the planned Round City, while later growth and loss make a complete street-level reconstruction uncertain.", "estimate"),
        ("People", "The city included courtly, scholarly, commercial and working communities with experiences that were not uniform.", "context"),
    ],
    "london": [
        ("Industry", "Factories, docks, railways and coal reshaped London’s economy and urban geography in the nineteenth century.", "documented"),
        ("Public health", "Crowding, pollution and sanitation inequality are documented in reports, maps and reform campaigns.", "documented"),
        ("Perspective", "A cinematic street view must avoid implying that one neighborhood or class represented all of Victorian London.", "context"),
    ],
}


def get_context(destination: dict[str, Any]) -> dict[str, Any]:
    location = str(destination.get("location", "")).lower()
    key = next((name for name in DESTINATION_CARDS if name in location), None)
    cards = DESTINATION_CARDS.get(key or "", []) + BASE_CARDS
    if destination.get("kind") == "prehistoric":
        cards = [
            ("Scientific reconstruction", "Paleoart combines fossils, geology, comparative anatomy and climate models; no complete snapshot survives.", "scientific"),
            ("Living systems", "Plants, animals and landscapes are shown as evidence-based hypotheses, not documentary footage.", "scientific"),
        ] + cards
    if destination.get("kind") == "future":
        cards = [
            ("Scenario", "This is a plausible design fiction, not a prediction or verified historical record.", "speculation"),
            ("Assumptions", "The scene makes its assumptions visible so visitors can question technology, ecology and social choices.", "speculation"),
        ] + cards
    return {
        "cards": [{"title": title, "text": text, "label": label} for title, text, label in cards],
        "timeline": _timeline(destination),
        "important_note": _note(destination),
    }


def _timeline(destination: dict[str, Any]) -> list[dict[str, str]]:
    kind = destination.get("kind")
    if kind == "future":
        return [{"year": "Now", "text": "Known present-day conditions"}, {"year": destination.get("year_label", "Future"), "text": "Speculative scenario"}]
    if kind == "prehistoric":
        return [{"year": "Deep time", "text": "Geological and fossil evidence"}, {"year": destination.get("year_label", "Ancient Earth"), "text": "Scientific reconstruction"}]
    return [{"year": "Before", "text": "Earlier context"}, {"year": destination.get("year_label", "Selected period"), "text": destination.get("era", "Historical period")}, {"year": "After", "text": "Later transformations"}]


def _note(destination: dict[str, Any]) -> str:
    if destination.get("kind") == "future":
        return "Future scenes are explicitly speculative scenarios, not factual forecasts."
    if destination.get("kind") == "prehistoric":
        return "Prehistoric scenes are scientifically informed paleoart built from incomplete evidence."
    return "Where evidence is incomplete, Chronoverse marks interpretation and estimates instead of inventing certainty."
