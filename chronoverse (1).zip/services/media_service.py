"""Source-aware historical media discovery using documented public APIs."""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from typing import Any


class MediaService:
    def __init__(self) -> None:
        self.youtube_key = os.getenv("YOUTUBE_API_KEY", "").strip()

    def search_commons(self, destination: dict[str, Any], category: str = "historical media", limit: int = 8) -> dict[str, Any]:
        query = f"{destination.get('location', '')} {destination.get('era', '')} {category}".strip()
        params = urllib.parse.urlencode({"action": "query", "generator": "search", "gsrsearch": query, "gsrnamespace": 6, "gsrlimit": max(1, min(limit, 12)), "prop": "imageinfo", "iiprop": "url|extmetadata|size|mime|mediatype", "iiurlwidth": 640, "format": "json", "origin": "*"})
        endpoint = f"https://commons.wikimedia.org/w/api.php?{params}"
        try:
            request = urllib.request.Request(endpoint, headers={"User-Agent": "Chronoverse/1.0 educational media explorer"})
            with urllib.request.urlopen(request, timeout=8) as response:
                payload = json.loads(response.read().decode("utf-8"))
            pages = payload.get("query", {}).get("pages", {}).values()
            items = [self._commons_item(page, destination) for page in pages]
            items = [item for item in items if item]
            return {"status": "ready", "provider": "Wikimedia Commons", "items": items, "query": query}
        except Exception as exc:
            return {"status": "fallback", "provider": "Wikimedia Commons", "items": [], "query": query, "message": f"Authentic media search is temporarily unavailable: {str(exc)[:120]}"}

    def featured_commons_image(self, destination: dict[str, Any]) -> dict[str, Any] | None:
        """Return one real Commons image for the arrival panel, never an AI reconstruction."""
        location = str(destination.get("location", "ancient site")).strip()
        queries = [
            f"{location} ruins archaeological site",
            f"{location} ancient ruins photograph",
            f"{location} archaeological monument",
        ]
        items: list[dict[str, Any]] = []
        seen: set[str] = set()
        for query in queries:
            result = self.search_commons({**destination, "location": location, "era": ""}, query, limit=8)
            for item in result.get("items", []):
                item_id = item.get("id") or item.get("original")
                if item_id and item_id not in seen:
                    seen.add(item_id)
                    items.append(item)
            if len(items) >= 8:
                break
        if not items:
            return None
        ranked = sorted(items, key=lambda item: self._photo_rank(item.get("title", ""), location), reverse=True)
        return ranked[0]

    @staticmethod
    def _photo_rank(title: str, location: str = "") -> int:
        lower = title.lower()
        location_lower = location.lower()
        score = 0
        if location_lower and location_lower in lower:
            score += 12
        aliases = {
            "giza": ("gizah", "pyramid"),
            "rome": ("roman", "colosseum", "coliseum", "circus maximus"),
            "samarkand": ("afras", "registan", "shah-i zinda"),
        }
        for alias in aliases.get(location_lower, ()):
            if alias in lower:
                score += 8
        for term in ("ruin", "temple", "forum", "pyramid", "palace", "archaeological", "site", "monument"):
            if term in lower:
                score += 3
        for term in ("pdf", "book", "dictionary", "map", "drawing", "plan"):
            if term in lower:
                score -= 8
        return score

    def _commons_item(self, page: dict[str, Any], destination: dict[str, Any]) -> dict[str, Any] | None:
        info = (page.get("imageinfo") or [{}])[0]
        preview = info.get("thumburl") or info.get("url")
        original = info.get("descriptionurl") or info.get("url")
        if not preview or not str(preview).startswith("http") or not str(original).startswith("http"):
            return None
        metadata = info.get("extmetadata") or {}
        if info.get("mediatype") not in (None, "BITMAP", "DRAWING"):
            return None
        mime = str(info.get("mime", "")).lower()
        if mime and not mime.startswith("image/"):
            return None
        if str(page.get("title", "")).lower().endswith((".pdf", ".djvu", ".svg")):
            return None
        def value(name: str) -> str:
            raw = metadata.get(name, {}).get("value", "")
            return str(raw).replace("\n", " ").strip()[:220]
        return {"id": str(page.get("pageid", "")), "title": str(page.get("title", "")).replace("File:", "").strip(), "preview": preview, "original": original, "source": "Wikimedia Commons", "creator": value("Artist") or "Creator not listed", "license": value("LicenseShortName") or "License information on source page", "date": value("Date") or destination.get("year_label", "Period varies"), "location": destination.get("location", ""), "category": "Authentic historical media"}

    def search_videos(self, destination: dict[str, Any], limit: int = 6) -> dict[str, Any]:
        query = f"{destination.get('location', '')} {destination.get('era', '')} documentary history".strip()
        if not self.youtube_key:
            link = "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": query})
            return {"status": "fallback", "provider": "YouTube search", "items": [], "query": query, "search_url": link, "message": "YouTube Data API is not configured. Use the official search fallback; videos are not scraped or autoplayed."}
        params = urllib.parse.urlencode({"part": "snippet", "q": query, "type": "video", "maxResults": max(1, min(limit, 10)), "safeSearch": "moderate", "key": self.youtube_key})
        endpoint = f"https://www.googleapis.com/youtube/v3/search?{params}"
        try:
            request = urllib.request.Request(endpoint, headers={"User-Agent": "Chronoverse/1.0"})
            with urllib.request.urlopen(request, timeout=8) as response:
                payload = json.loads(response.read().decode("utf-8"))
            items = []
            for item in payload.get("items", []):
                snippet = item.get("snippet", {})
                video_id = item.get("id", {}).get("videoId")
                if not video_id:
                    continue
                items.append({"id": video_id, "title": snippet.get("title", "Untitled"), "description": snippet.get("description", ""), "channel": snippet.get("channelTitle", "Unknown channel"), "published": snippet.get("publishedAt", "")[:10], "thumbnail": snippet.get("thumbnails", {}).get("medium", {}).get("url"), "url": f"https://www.youtube.com/watch?v={video_id}", "embed_url": f"https://www.youtube-nocookie.com/embed/{video_id}", "source": "YouTube Data API"})
            return {"status": "ready", "provider": "YouTube Data API", "items": items, "query": query}
        except Exception as exc:
            return {"status": "fallback", "provider": "YouTube search", "items": [], "query": query, "search_url": "https://www.youtube.com/results?" + urllib.parse.urlencode({"search_query": query}), "message": f"Video discovery is temporarily unavailable: {str(exc)[:120]}"}
