"""Optional asynchronous AI video provider boundary.

The default implementation is intentionally unavailable. A real provider can be
connected through VIDEO_PROVIDER_URL without exposing credentials to the browser.
"""
from __future__ import annotations

import os
from typing import Any


class VideoGenerationService:
    def __init__(self) -> None:
        self.provider_url = os.getenv("VIDEO_PROVIDER_URL", "").strip()

    def status(self) -> dict[str, Any]:
        return {"configured": bool(self.provider_url), "provider": "configured backend adapter" if self.provider_url else "not configured"}

    def generate(self, destination: dict[str, Any], scene: str) -> dict[str, Any]:
        if not self.provider_url:
            return {"ok": False, "status": "unavailable", "provider": "not configured", "message": "AI video generation is unavailable until an official provider is configured. No fake video was created."}
        # Provider-specific async job submission belongs here. Until its official
        # request/response contract is configured, fail closed instead of guessing.
        return {"ok": False, "status": "not_implemented", "provider": "configured backend adapter", "message": "The provider boundary is configured, but its official asynchronous job contract still needs implementation."}
