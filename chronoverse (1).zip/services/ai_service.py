"""Optional OpenAI-compatible adapters for text and image generation."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


IMAGE_LABEL = "AI-GENERATED RECONSTRUCTION — NOT AN AUTHENTIC HISTORICAL PHOTOGRAPH."
OFFLINE_IMAGE_LABEL = "OFFLINE ARTISTIC RECONSTRUCTION — NOT AN AUTHENTIC HISTORICAL PHOTOGRAPH."


class AIService:
    def __init__(self, cache_dir: str | Path = "data/generated") -> None:
        self.api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._inflight: set[str] = set()

    @property
    def text_available(self) -> bool:
        return bool(self.api_key)

    @property
    def image_available(self) -> bool:
        return bool(self.api_key)

    def ask_chronos(self, message: str, destination: dict[str, Any], conversation: list[dict[str, str]] | None = None) -> dict[str, Any]:
        if self.api_key:
            try:
                return self._remote_chat(message, destination, conversation or [])
            except Exception as exc:
                # A provider outage should not erase the visitor's journey.
                return self._offline_chat(message, destination, self._safe_provider_error(exc))
        return self._offline_chat(message, destination)

    @staticmethod
    def _safe_provider_error(exc: Exception) -> dict[str, Any]:
        """Return a diagnosis safe to send to the browser, never raw provider text."""
        if isinstance(exc, urllib.error.HTTPError):
            status = int(exc.code)
            category = {
                401: "authentication",
                403: "permission",
                429: "quota_or_rate_limit",
            }.get(status, "provider_http_error")
            return {"category": category, "status": status}
        if isinstance(exc, urllib.error.URLError):
            return {"category": "network", "status": None}
        if isinstance(exc, (ValueError, json.JSONDecodeError)):
            return {"category": "provider_response", "status": None}
        return {"category": "provider_unavailable", "status": None}

    def _remote_chat(self, message: str, destination: dict[str, Any], conversation: list[dict[str, str]]) -> dict[str, Any]:
        system = (
            "You are CHRONOS, a careful historical exploration assistant. Answer in concise, vivid prose. "
            "Always label claims as documented fact, archaeological evidence, historical estimate, scientific reconstruction, "
            "or speculative future scenario. Never invent citations or present uncertain details as verified. "
            f"Current destination: {destination.get('title')}; context: {destination.get('prompt_context')}"
        )
        messages: list[dict[str, str]] = [{"role": "system", "content": system}]
        for item in conversation[-8:]:
            role = "assistant" if item.get("role") == "assistant" else "user"
            messages.append({"role": role, "content": str(item.get("content") or "")[:1200]})
        messages.append({"role": "user", "content": message[:2000]})
        body = json.dumps({"model": os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini"), "messages": messages, "temperature": 0.35, "max_tokens": 450}).encode()
        request = urllib.request.Request(f"{self.base_url}/chat/completions", data=body, headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(request, timeout=18) as response:
            payload = json.loads(response.read().decode("utf-8"))
        text = payload.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
        if not text:
            raise ValueError("CHRONOS returned an empty response")
        return {"reply": text, "mode": "ai", "evidence": "AI interpretation; verify specific claims against cited sources.", "confidence": "contextual"}

    def _offline_chat(self, message: str, destination: dict[str, Any], provider_error: dict[str, Any] | None = None) -> dict[str, Any]:
        lower = message.lower()
        title = destination.get("title", "this destination")
        kind = destination.get("kind", "historical")
        if "eat" in lower or "food" in lower:
            reply = f"At {title}, food depended strongly on status and region. CHRONOS can outline documented ingredients and recipes, but a single ‘typical meal’ would overstate the evidence. Ask for a household, social class or season for a more precise reconstruction."
            evidence = "Historical interpretation based on material, textual and comparative evidence."
        elif "build" in lower or "house" in lower or "architecture" in lower:
            reply = f"For {title}, building methods are best explained through surviving structures, tools, materials and archaeological traces. I can describe a plausible workflow, while marking which steps are directly evidenced and which are informed reconstruction."
            evidence = "Archaeological evidence plus clearly marked reconstruction."
        elif "street" in lower or "look" in lower or "scene" in lower:
            reply = f"A street-level view of {title} is a reconstruction rather than an authentic photograph. The broad setting can follow known geography, buildings and transport; crowd density, colors and incidental details are interpretive."
            evidence = "Scientific or historical reconstruction; not a direct observation."
        elif kind == "future":
            reply = f"This {title} scenario is speculative. It explores one plausible combination of technology, climate and urban choices, not a verified forecast. I can change the assumptions and show a different future."
            evidence = "Speculative future scenario."
        elif kind == "prehistoric":
            reply = f"{title} is presented as scientifically informed paleoart. Fossils, geology and comparative biology constrain the scene, but the exact colors, sounds and daily behavior remain uncertain."
            evidence = "Scientific reconstruction from incomplete evidence."
        else:
            reply = f"You are now examining {title}. I can explain its timeline, architecture, technology, economy, clothing, food, transportation and social life. I’ll distinguish documented facts from estimates and interpretation as we go."
            evidence = "Contextual historical summary; specific details should be checked against primary or museum sources."
        result: dict[str, Any] = {"reply": reply, "mode": "offline", "evidence": evidence, "confidence": "guarded"}
        if provider_error:
            result["provider_error"] = provider_error
        return result

    def generate_image(self, destination: dict[str, Any], scene: str = "arrival panorama") -> dict[str, Any]:
        prompt_context = destination.get("prompt_context", "historical destination")
        cache_key = hashlib.sha256(json.dumps({"destination": destination.get("key"), "scene": scene, "v": 1}, sort_keys=True).encode()).hexdigest()[:24]
        file_path = self.cache_dir / f"{cache_key}.png"
        if file_path.exists() and file_path.stat().st_size > 512:
            return {"ok": True, "status": "ready", "cached": True, "image_url": f"/generated/{file_path.name}", "label": IMAGE_LABEL}
        if not self.api_key:
            return self._offline_image(destination)
        with self._lock:
            if cache_key in self._inflight:
                return {"ok": False, "status": "in_progress", "reason": "This reconstruction is already being generated.", "label": IMAGE_LABEL}
            self._inflight.add(cache_key)
        try:
            prompt = (
                f"Create a cinematic but historically responsible visual reconstruction of {destination.get('title')}. "
                f"Context: {prompt_context} Scene: {scene}. Use period-appropriate architecture, clothing, materials, geography and light. "
                "Do not include text, logos, modern objects, or claims of photographic authenticity."
            )
            body = json.dumps({"model": os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1"), "prompt": prompt, "size": "1024x1024", "quality": "medium"}).encode()
            request = urllib.request.Request(f"{self.base_url}/images/generations", data=body, headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(request, timeout=45) as response:
                payload = json.loads(response.read().decode("utf-8"))
            item = payload.get("data", [{}])[0]
            encoded = item.get("b64_json")
            image_url = item.get("url")
            if encoded:
                raw = base64.b64decode(encoded, validate=True)
                if not raw.startswith(b"\x89PNG") or len(raw) < 512:
                    raise ValueError("image response validation failed")
                file_path.write_bytes(raw)
                return {"ok": True, "status": "ready", "cached": False, "image_url": f"/generated/{file_path.name}", "label": IMAGE_LABEL}
            if image_url and re.match(r"^https://", image_url):
                return {"ok": True, "status": "ready", "cached": False, "image_url": image_url, "label": IMAGE_LABEL, "temporary": True}
            raise ValueError("image response did not contain a valid image")
        except (urllib.error.URLError, ValueError, json.JSONDecodeError, OSError) as exc:
            # Keep the visual journey useful even when OpenAI is out of credits.
            return self._offline_image(destination, f"OpenAI unavailable ({self._safe_provider_error(exc)['category']}); local fallback loaded.")
        finally:
            with self._lock:
                self._inflight.discard(cache_key)

    @staticmethod
    def _offline_image(destination: dict[str, Any], reason: str = "OpenAI is not configured; local fallback loaded.") -> dict[str, Any]:
        text = f"{destination.get('title', '')} {destination.get('location', '')}".lower()
        scene = "world"
        for tokens, candidate in ((
            (("rome", "gaul", "iberia", "greece", "anatolia"), "rome"),
            (("egypt", "giza", "nile"), "egypt"),
            (("persia", "iran", "mesopotamia", "levant", "aksum", "ethiopia"), "persia"),
            (("india", "ganges"), "india"),
            (("china", "korea", "japan"), "china"),
            (("mesoamerica", "maya", "mexico"), "mesoamerica"),
            (("andes", "peru", "inca"), "andes"),
            (("silk", "samarkand", "central asia"), "silk-road"),
        )):
            if any(token in text for token in tokens):
                scene = candidate
                break
        return {"ok": True, "status": "offline_ready", "cached": False, "offline": True, "reason": reason, "image_url": f"/static/offline/{scene}.svg", "label": OFFLINE_IMAGE_LABEL}
