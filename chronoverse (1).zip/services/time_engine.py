"""Natural-language destination normalization for Chronoverse."""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class Destination:
    title: str
    location: str
    year_label: str
    year: int | None
    era: str
    kind: str
    key: str
    certainty: str
    prompt_context: str
    suggestions: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


KNOWN_DESTINATIONS = [
    {
        "match": ("rome", "roman empire", "roman"),
        "location": "Rome",
        "title": "Ancient Rome",
        "year": 117,
        "year_label": "117 CE",
        "era": "High Roman Empire",
        "kind": "historical",
        "prompt_context": "Imperial Rome at the height of its urban, architectural and road-building systems.",
        "suggestions": ["Ask about ordinary Roman food", "Explore the Forum and markets", "See Roman engineering"],
    },
    {
        "match": ("egypt", "great pyramid", "giza", "pharaoh"),
        "location": "Giza, Egypt",
        "title": "The Pyramid Age",
        "year": -2560,
        "year_label": "c. 2560 BCE",
        "era": "Fourth Dynasty Egypt",
        "kind": "historical",
        "prompt_context": "The Giza plateau during the Fourth Dynasty, with construction understood through archaeological evidence and informed reconstruction.",
        "suggestions": ["How could the pyramid be built?", "Explore workers’ settlements", "Ask about ancient Egyptian food"],
    },
    {
        "match": ("samarkand", "silk road"),
        "location": "Samarkand, Central Asia",
        "title": "Samarkand on the Silk Road",
        "year": 750,
        "year_label": "c. 750 CE",
        "era": "Early Islamic / Silk Road era",
        "kind": "historical",
        "prompt_context": "Samarkand as a crossroads of trade, craft, scholarship and cultural exchange; the exact street-level appearance varies by period and evidence.",
        "suggestions": ["Follow a caravan route", "Explore crafts and markets", "Ask about languages and trade"],
    },
    {
        "match": ("baghdad", "abbasid", "abbasid caliphate"),
        "location": "Baghdad, Iraq",
        "title": "Baghdad in the Abbasid Golden Age",
        "year": 830,
        "year_label": "c. 830 CE",
        "era": "Abbasid Caliphate",
        "kind": "historical",
        "prompt_context": "Baghdad during the Abbasid period, with the House of Wisdom and scholarly networks presented with care around disputed details.",
        "suggestions": ["Visit the scholarly circles", "Explore the round city", "Ask about mathematics and astronomy"],
    },
    {
        "match": ("london", "industrial revolution", "industrial"),
        "location": "London, England",
        "title": "London and the Industrial Revolution",
        "year": 1850,
        "year_label": "c. 1850 CE",
        "era": "Industrial Revolution",
        "kind": "historical",
        "prompt_context": "Nineteenth-century London shaped by factories, railways, expanding neighborhoods and severe public-health inequalities.",
        "suggestions": ["Walk through a working neighborhood", "Explore rail and industry", "Ask about public health"],
    },
    {
        "match": ("prehistoric", "jurassic", "dinosaurs", "150 million", "cretaceous", "ancient earth"),
        "location": "Earth",
        "title": "Deep Time Earth",
        "year": -150_000_000,
        "year_label": "150 million years ago",
        "era": "Late Jurassic / deep time",
        "kind": "prehistoric",
        "prompt_context": "A scientifically informed paleoenvironment; species, climate and geography are reconstructed from incomplete geological and fossil evidence.",
        "suggestions": ["Explore a Jurassic ecosystem", "Ask how paleontologists know", "See ancient oceans"],
    },
]


# Modern borders do not map neatly onto ancient states. These curated atlas entries
# provide a useful first period for common country/region queries, while the UI
# clearly labels the result as an interpretation rather than a literal modern nation.
ATLAS_DESTINATIONS = [
    {"match": ("greece", "athens", "hellenic", "mycenae"), "location": "Greece", "title": "Classical Greece", "year": -450, "year_label": "c. 450 BCE", "era": "Classical Greek world", "kind": "historical", "prompt_context": "The Greek city-state world of the Classical period, with Athens, Sparta and many other communities treated as distinct societies rather than one modern nation.", "suggestions": ["Explore Athens and the agora", "Ask about Greek daily life", "Compare city-states"]},
    {"match": ("persia", "iran", "achaemenid", "parsa"), "location": "Iran", "title": "Achaemenid Persia", "year": -500, "year_label": "c. 500 BCE", "era": "Achaemenid Empire", "kind": "historical", "prompt_context": "The Achaemenid imperial world across Iranian plateau, Mesopotamia and connected provinces; modern borders are not ancient boundaries.", "suggestions": ["Visit Persepolis", "Follow the Royal Road", "Ask about imperial administration"]},
    {"match": ("china", "qin", "han dynasty", "han china"), "location": "China", "title": "Han-era China", "year": 100, "year_label": "c. 100 CE", "era": "Han dynasty", "kind": "historical", "prompt_context": "Han China through cities, farming, bureaucracy, craft and long-distance exchange, with regional variation kept visible.", "suggestions": ["Explore Chang'an", "Ask about the Silk Road", "See Han technology"]},
    {"match": ("india", "maurya", "gupta", "ganges"), "location": "India", "title": "Mauryan India", "year": -250, "year_label": "c. 250 BCE", "era": "Mauryan Empire", "kind": "historical", "prompt_context": "The Mauryan period across a diverse South Asian landscape; political control, languages and everyday life varied by region.", "suggestions": ["Explore Pataliputra", "Ask about Ashoka's inscriptions", "Follow ancient trade"]},
    {"match": ("japan", "yamato", "yayoi", "nara"), "location": "Japan", "title": "Yayoi Japan", "year": 200, "year_label": "c. 200 CE", "era": "Yayoi period", "kind": "historical", "prompt_context": "The Yayoi-period Japanese archipelago, reconstructed from archaeology, settlement evidence and regional exchange.", "suggestions": ["Explore Yayoi settlements", "Ask about rice farming", "See ancient craft"]},
    {"match": ("korea", "goguryeo", "baekje", "silla"), "location": "Korean Peninsula", "title": "The Three Kingdoms of Korea", "year": 500, "year_label": "c. 500 CE", "era": "Three Kingdoms period", "kind": "historical", "prompt_context": "Competing kingdoms and connected communities on the Korean Peninsula, not a single uniform ancient country.", "suggestions": ["Compare the three kingdoms", "Explore fortresses", "Ask about Buddhist exchange"]},
    {"match": ("turkey", "anatolia", "hittite", "byzantium", "constantinople"), "location": "Anatolia", "title": "Anatolia at the Crossroads", "year": 100, "year_label": "c. 100 CE", "era": "Roman Anatolia", "kind": "historical", "prompt_context": "Anatolia as a layered crossroads of older kingdoms, Roman cities, local communities and routes between continents.", "suggestions": ["Explore Ephesus", "Follow the Anatolian roads", "Ask about layered cities"]},
    {"match": ("mesopotamia", "iraq", "sumer", "babylon", "assyria"), "location": "Mesopotamia", "title": "Mesopotamian Cities", "year": -600, "year_label": "c. 600 BCE", "era": "Neo-Babylonian Mesopotamia", "kind": "historical", "prompt_context": "The river plains of Mesopotamia, where cities, temples, irrigation and empires changed across millennia.", "suggestions": ["Visit Babylon", "Ask about cuneiform", "Explore irrigation"]},
    {"match": ("levant", "syria", "jordan", "lebanon", "phoenicia"), "location": "The Levant", "title": "The Ancient Levant", "year": -500, "year_label": "c. 500 BCE", "era": "Eastern Mediterranean", "kind": "historical", "prompt_context": "A multilingual, connected Levantine corridor of ports, inland towns and empires; no single modern national identity is projected backward.", "suggestions": ["Follow Phoenician routes", "Explore ancient ports", "Ask about languages"]},
    {"match": ("ethiopia", "axum", "aksum"), "location": "Aksum, Ethiopia", "title": "Aksum and the Red Sea", "year": 350, "year_label": "c. 350 CE", "era": "Aksumite Kingdom", "kind": "historical", "prompt_context": "Aksumite power linking the Horn of Africa, the Nile world, Arabia and the Red Sea through trade and monumental culture.", "suggestions": ["Explore Aksumite stelae", "Follow Red Sea trade", "Ask about early Christianity"]},
    {"match": ("mali", "ghana empire", "songhai", "timbuktu"), "location": "West Africa", "title": "West African Sahel Empires", "year": 1300, "year_label": "c. 1300 CE", "era": "Mali Empire", "kind": "historical", "prompt_context": "Sahelian cities, scholarship and gold-salt exchange, with oral, archaeological and written evidence combined carefully.", "suggestions": ["Explore Timbuktu", "Follow the trans-Saharan routes", "Ask about scholarship"]},
    {"match": ("mexico", "maya", "aztec", "teotihuacan", "mesoamerica"), "location": "Mesoamerica", "title": "Mesoamerican Cities", "year": 650, "year_label": "c. 650 CE", "era": "Classic / Postclassic Mesoamerica", "kind": "historical", "prompt_context": "A mosaic of Mesoamerican cultures and cities; Maya, Teotihuacan and later Mexica histories are not interchangeable.", "suggestions": ["Explore Maya cities", "Ask about calendars", "Compare urban centers"]},
    {"match": ("peru", "inca", "andean", "cusco"), "location": "Andes", "title": "The Andean World", "year": 1450, "year_label": "c. 1450 CE", "era": "Late Andean civilizations", "kind": "historical", "prompt_context": "Andean roads, terraces, communities and imperial administration, with multiple cultures and landscapes beyond a single Inca story.", "suggestions": ["Follow the mountain roads", "Explore terraces", "Ask about quipu and administration"]},
    {"match": ("cambodia", "khmer", "angkor"), "location": "Angkor, Cambodia", "title": "Angkor and the Khmer World", "year": 1150, "year_label": "c. 1150 CE", "era": "Khmer Empire", "kind": "historical", "prompt_context": "Angkor's temples, reservoirs and urban networks interpreted through archaeology, inscriptions and landscape evidence.", "suggestions": ["Explore Angkor Wat", "Ask about water systems", "See temple inscriptions"]},
    {"match": ("indonesia", "java", "srivijaya", "borobudur"), "location": "Maritime Southeast Asia", "title": "Maritime Southeast Asia", "year": 800, "year_label": "c. 800 CE", "era": "Sailendra and Srivijaya worlds", "kind": "historical", "prompt_context": "Island and coastal societies connected by monsoon sailing, trade, Buddhism and local political networks.", "suggestions": ["Explore Borobudur", "Follow monsoon routes", "Ask about maritime trade"]},
    {"match": ("france", "gaul", "gallic"), "location": "Gaul", "title": "Gaul Before and During Rome", "year": 50, "year_label": "c. 50 BCE", "era": "Late Iron Age Gaul", "kind": "historical", "prompt_context": "A diverse Iron Age Gaul of communities and trade routes, later reshaped by Roman conquest; not a direct image of modern France.", "suggestions": ["Explore a Gallic settlement", "Ask about Roman contact", "Follow Atlantic trade"]},
    {"match": ("spain", "iberia", "iberian", "tartessos"), "location": "Iberia", "title": "Ancient Iberia", "year": -200, "year_label": "c. 200 BCE", "era": "Iberian and Roman worlds", "kind": "historical", "prompt_context": "The Iberian Peninsula as a meeting ground of local communities, Phoenician and Greek networks, and Rome.", "suggestions": ["Explore Iberian hillforts", "Ask about Mediterranean trade", "See Roman transition"]},
    {"match": ("germany", "germanic", "germania"), "location": "Germania", "title": "Germanic Lands Beyond Rome", "year": 100, "year_label": "c. 100 CE", "era": "Roman frontier", "kind": "historical", "prompt_context": "Communities beyond the Roman frontier described through archaeology and Roman accounts, with ancient identities kept distinct from modern Germany.", "suggestions": ["Explore the frontier", "Ask about forests and farms", "Compare Roman and local evidence"]},
    {"match": ("australia", "aboriginal", "first nations"), "location": "Australia", "title": "Deep History of Australia", "year": -1000, "year_label": "c. 1000 BCE", "era": "Ancient First Nations landscapes", "kind": "historical", "prompt_context": "A deep, living cultural history of First Nations peoples; specific communities, Country and knowledge systems must not be collapsed into one generic scene.", "suggestions": ["Learn about Country", "Ask about ancient land management", "Explore rock art evidence"]},
    {"match": ("brazil", "amazon", "marajoara"), "location": "Amazonia", "title": "Ancient Amazonian Landscapes", "year": 1000, "year_label": "c. 1000 CE", "era": "Pre-Columbian Amazonia", "kind": "historical", "prompt_context": "Amazonian societies and managed landscapes reconstructed from archaeology, ecology and Indigenous knowledge, not an untouched wilderness cliché.", "suggestions": ["Explore earthworks", "Ask about forest management", "See river networks"]},
]

KNOWN_DESTINATIONS.extend(ATLAS_DESTINATIONS)


def _year_from_text(text: str) -> tuple[int | None, str | None]:
    lower = text.lower()
    million = re.search(r"(\d+(?:\.\d+)?)\s*million\s+years?", lower)
    if million:
        value = int(float(million.group(1)) * 1_000_000)
        return -value, f"{million.group(1).rstrip('0').rstrip('.')} million years ago"
    bc = re.search(r"(\d{1,6})\s*(?:bce|bc)", lower)
    if bc:
        value = -int(bc.group(1))
        return value, f"{bc.group(1)} BCE"
    ce = re.search(r"(\d{1,5})\s*(?:ce|ad)\b", lower)
    if ce:
        value = int(ce.group(1))
        return value, f"{ce.group(1)} CE"
    plain = re.search(r"\b(\d{3,4})\b", lower)
    if plain:
        value = int(plain.group(1))
        if value > 2026:
            return value, str(value)
        return value, f"{value} CE"
    offset = re.search(r"(\d+)\s+years?\s+into\s+the\s+future", lower)
    if offset:
        value = 2026 + int(offset.group(1))
        return value, f"{value} CE (speculative future)"
    return None, None


def resolve_destination(query: str, previous: dict[str, Any] | None = None) -> Destination:
    """Resolve a visitor request without pretending uncertain details are facts."""
    text = (query or "").strip()
    lower = text.lower()
    parsed_year, parsed_label = _year_from_text(text)

    selected = next((item for item in KNOWN_DESTINATIONS if any(token in lower for token in item["match"])), None)
    if selected:
        year = parsed_year if parsed_year is not None else selected["year"]
        label = parsed_label or selected["year_label"]
        future = year is not None and year > 2026
        kind = "future" if future else selected["kind"]
        era = "Speculative future" if future else selected["era"]
        certainty = "speculative" if future else ("scientific reconstruction" if kind == "prehistoric" else "documented + interpreted")
        title = f"{selected['location']} in {label}" if parsed_year is not None else selected["title"]
        return Destination(title, selected["location"], label, year, era, kind,
                           _key(selected["location"], year), certainty,
                           selected["prompt_context"], selected["suggestions"])

    if previous and not any(word in lower for word in ("take me", "show me", "travel", "go to", "visit", "explore", "year ")):
        return Destination(
            title=str(previous.get("title") or "Current destination"),
            location=str(previous.get("location") or "Unknown location"),
            year_label=str(previous.get("year_label") or "date not specified"),
            year=previous.get("year") if isinstance(previous.get("year"), int) else None,
            era=str(previous.get("era") or "Historical period"),
            kind=str(previous.get("kind") or "historical"),
            key=str(previous.get("key") or "current-destination"),
            certainty=str(previous.get("certainty") or "contextual"),
            prompt_context=str(previous.get("prompt_context") or "Current destination context."),
            suggestions=[str(item) for item in previous.get("suggestions", []) if item],
        )

    place_match = re.search(r"(?:to|in|at|near)\s+([A-Z][\w-]*(?:\s+[A-Z][\w-]*){0,3})", text)
    location = place_match.group(1).strip() if place_match else "An uncharted destination"
    if parsed_year is not None and parsed_year > 2026:
        kind, era, certainty = "future", "Speculative future", "speculative"
    elif parsed_year is not None and parsed_year < -10_000:
        kind, era, certainty = "prehistoric", "Deep time", "scientific reconstruction"
    else:
        kind, era, certainty = "historical", "Historical period", "requires contextual evidence"
    label = parsed_label or "date not specified"
    title = f"{location} · {label}" if location != "An uncharted destination" else "An uncharted destination"
    return Destination(title, location, label, parsed_year, era, kind, _key(location, parsed_year), certainty,
                       "This destination needs contextual interpretation; specific details depend on surviving evidence.",
                       ["Ask what is documented", "Explore architecture and daily life", "Request a source-aware reconstruction"])


def _key(location: str, year: int | None) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", location.lower()).strip("-")
    return f"{slug}-{year if year is not None else 'undated'}"


def is_journey_request(message: str) -> bool:
    lower = (message or "").lower()
    return any(phrase in lower for phrase in ("take me", "show me", "travel", "go to", "visit", "explore", "time travel", "bring me"))
