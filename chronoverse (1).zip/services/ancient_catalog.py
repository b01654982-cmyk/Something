"""Additional ancient polities and cultural regions for the Chronoverse atlas.

These are intentionally described as time-bounded journeys, not modern-country
proxies. The visual layer searches Commons at request time and labels results as
archive media or reconstruction.
"""
from __future__ import annotations

# name, approximate year, era label. The catalog is a discovery index; individual
# dossier claims remain evidence-aware and should be checked against sources.
_GROUPS: list[tuple[str, int, str, tuple[str, ...]]] = [
    ("Mesopotamia and the Levant", -900, "Ancient Near Eastern worlds", (
        "Sumer", "Akkad", "Ur", "Uruk", "Lagash", "Mari", "Ebla", "Nippur",
        "Nineveh", "Nimrud", "Assyria", "Neo-Assyria", "Babylon", "Neo-Babylonia",
        "Hittite Empire", "Mitanni", "Elam", "Susa", "Ugarit", "Aramean States",
        "Phoenicia", "Tyre", "Sidon", "Byblos", "Kingdom of Israel", "Kingdom of Judah",
        "Nabataea", "Palmyra", "Pella", "Jericho", "Jerusalem", "Damascus",
        "Canaan", "Edom", "Moab", "Ammon", "Dilmun", "Magan", "Qatna", "Carchemish",
    )),
    ("Egypt and North Africa", -1200, "Ancient North African worlds", (
        "Predynastic Egypt", "Old Kingdom Egypt", "Middle Kingdom Egypt", "New Kingdom Egypt",
        "Ptolemaic Egypt", "Memphis Egypt", "Thebes Egypt", "Amarna", "Abu Simbel",
        "Kush", "Kerma", "Napata", "Meroe", "Punt", "Cyrene", "Carthage", "Numidia",
        "Mauretania", "Garamantes", "Leptis Magna", "Sabratha", "Oea", "Tripolitania",
        "Ancient Libya", "Nile Valley", "Siwa Oasis", "Alexandria Egypt", "Fayoum",
        "Dakhla Oasis", "Kharga Oasis", "Tanis", "Bubastis", "Saqqara", "Dendera",
        "Esna", "Edfu", "Philae", "Abydos", "Nubia", "Ancient Maghreb",
    )),
    ("Iran, Arabia and Central Asia", -500, "Iranian and Inner Asian worlds", (
        "Median Empire", "Parthia", "Sasanian Empire", "Persian Gulf", "Elamite Susa",
        "Pasargadae", "Persepolis", "Ecbatana", "Ctesiphon", "Sogdia", "Bactria",
        "Bactrian Kingdom", "Kushan Empire", "Greco-Bactria", "Khwarezm", "Margiana",
        "Merv", "Balkh", "Herat", "Bamiyan", "Nisa", "Turkmenistan Bronze Age",
        "Scythia", "Saka", "Massagetae", "Parthian Nisa", "Aria", "Cappadocia",
        "Lydia", "Phrygia", "Urartu", "Armenia Antiquity", "Commagene", "Osroene",
        "Dilmun Arabia", "Saba", "Himyar", "Qataban", "Hadramaut", "Oman Antiquity",
        "Gerrha", "Dedan", "Tayma", "Al Ula Antiquity", "Petra Nabataea", "Aksumite Arabia",
    )),
    ("South Asia", -250, "South Asian ancient worlds", (
        "Indus Valley Civilization", "Harappa", "Mohenjo-daro", "Dholavira", "Lothal",
        "Gandhara", "Taxila", "Magadha", "Maurya", "Pataliputra", "Shunga Dynasty",
        "Satavahana", "Kalinga", "Kosala", "Avanti", "Vatsa", "Gandharan Kingdom",
        "Indo-Greek Kingdoms", "Indo-Scythians", "Indo-Parthians", "Gupta Empire",
        "Vakataka", "Chola", "Chera", "Pandya", "Pallava", "Kushan India",
        "Sanchi", "Nalanda", "Ajanta", "Ellora", "Amaravati India", "Udayagiri India",
        "Ladakh Antiquity", "Kashmir Antiquity", "Nepal Licchavi", "Ancient Bengal",
        "Pundra", "Kamarupa", "Sri Lanka Anuradhapura", "Jaffna Antiquity", "Maldives Antiquity",
        "Ancient Odisha", "Deccan Megaliths", "Konkan Antiquity", "Tamilakam", "Karnataka Antiquity",
        "Gujarat Antiquity", "Rajasthan Antiquity", "Bihar Antiquity", "Afghanistan Gandhara",
    )),
    ("East Asia", 200, "East Asian ancient worlds", (
        "Xia Dynasty", "Shang Dynasty", "Zhou Dynasty", "Spring and Autumn China", "Warring States China",
        "Qin Dynasty", "Han Dynasty", "Three Kingdoms China", "Wei Kingdom", "Wu Kingdom",
        "Shu Han", "Jin Dynasty China", "Northern Wei", "Sui Dynasty", "Tang Chang'an",
        "Chu", "Qi China", "Yan China", "Zhao China", "Yue China", "Baekje", "Silla",
        "Goguryeo", "Gaya Confederacy", "Balhae", "Joseon Antiquity", "Korea Jeulmun",
        "Yayoi Japan", "Kofun Japan", "Yamato Japan", "Asuka Japan", "Nara Japan",
        "Ryukyu Antiquity", "Jomon Japan", "Tibetan Empire", "Nanzhao", "Dali Kingdom",
        "Xiongnu", "Rouran Khaganate", "Göktürks", "Tarim Basin", "Loulan", "Khotan",
        "Kucha", "Turpan", "Yuezhi", "Wusun", "Northeast China Bronze Age", "Ancient Manchuria",
    )),
    ("Southeast Asia and Oceania", 700, "Southeast Asian and Pacific ancient worlds", (
        "Funan", "Chenla", "Champa", "Dvaravati", "Pyu City States", "Pagan Kingdom",
        "Thaton", "Mon Kingdoms", "Lan Xang Antiquity", "Haripunjaya", "Srivijaya",
        "Sailendra", "Mataram Kingdom", "Majapahit", "Tarumanagara", "Kutai",
        "Kedah Tua", "Langkasuka", "Chitu", "Tambralinga", "Oc Eo", "Angkor Thom",
        "Pre-Angkor Cambodia", "Bali Antiquity", "Timor Antiquity", "Philippines Barangay",
        "Maritime Silk Road", "Lapita Culture", "Polynesia Ancient", "Micronesia Ancient",
        "Melanesia Ancient", "Papua Highlands Antiquity", "Aboriginal Australia Rock Art",
        "New Zealand Maori Origins", "Hawaii Polynesian Origins", "Easter Island Rapa Nui",
        "Guam Latte Culture", "Vanuatu Lapita", "Solomon Islands Lapita", "New Caledonia Lapita",
    )),
    ("Europe and the Mediterranean", -300, "European and Mediterranean ancient worlds", (
        "Minoan Crete", "Mycenaean Greece", "Cycladic Civilization", "Archaic Greece", "Athens",
        "Sparta", "Corinth", "Thebes Greece", "Delphi", "Macedon", "Alexander's Empire",
        "Hellenistic Egypt", "Seleucid Empire", "Ptolemaic Alexandria", "Pergamon", "Rhodes Antiquity",
        "Etruscans", "Latins", "Sabines", "Samnites", "Roman Republic", "Roman Britain",
        "Roman Gaul", "Roman Hispania", "Roman Africa", "Roman Egypt", "Roman Syria",
        "Roman Anatolia", "Byzantine Constantinople", "Ravenna Antiquity", "Ostrogothic Italy",
        "Visigothic Iberia", "Celtic Britain", "Druidic Gaul", "Lusitania", "Tartessos",
        "Celtiberia", "Etruscan Veii", "Illyria", "Thrace", "Dacian Kingdom", "Getae",
        "Scordisci", "Pannonia", "Noricum", "Sarmatians", "Gothic Worlds", "Viking Age Scandinavia",
        "Germanic Frontier", "Baltic Iron Age", "Etruscan Tarquinia", "Pompeii", "Herculaneum",
        "Ostia Antica", "Hadrians Wall", "Delos", "Knossos", "Olympia", "Epidaurus",
    )),
    ("Sub-Saharan Africa", 500, "African ancient and early historic worlds", (
        "Nok Culture", "Jenne-jeno", "Ghana Empire", "Mali Empire", "Songhai Empire", "Kanem-Bornu",
        "Kushite Sudan", "Aksum", "Adulis", "D'mt", "Swahili Coast Antiquity", "Kilwa Origins",
        "Mogadishu Antiquity", "Pate Antiquity", "Great Zimbabwe", "Mapungubwe", "Bantu Iron Age",
        "San Rock Art", "Khoisan Ancient Landscapes", "Congo Basin Antiquity", "Nubian Kingdoms",
        "Benin Origins", "Ife", "Oyo Origins", "Igbo Ukwu", "Tichitt Culture", "Djenné",
        "Timbuktu Origins", "Agadez Antiquity", "Sao Civilization", "Meroitic Sudan", "Axum",
        "Lalibela Origins", "Ethiopian Highlands Antiquity", "Lake Chad Civilizations", "Nile Cataracts",
        "Ancient Eritrea", "Ancient Somalia", "Ancient Kenya", "Ancient Tanzania", "Ancient Uganda",
        "Ancient Zimbabwe", "Ancient Mozambique", "Ancient South Africa", "Ancient Namibia",
        "Ancient Botswana", "Ancient Madagascar", "Comoros Antiquity", "Seychelles Antiquity",
    )),
    ("The Americas", 600, "American ancient worlds", (
        "Olmec", "Maya", "Teotihuacan", "Zapotec", "Mixtec", "Toltec", "Mexica",
        "Tarascan State", "Huastec", "Totonac", "Cholula", "Monte Alban", "Palenque",
        "Tikal", "Copan", "Chichen Itza", "Calakmul", "Uxmal", "Caracol Maya", "El Mirador",
        "Moche", "Nazca", "Chavin", "Paracas", "Wari", "Tiwanaku", "Inca", "Chimu",
        "Muisca", "Cañari", "Caral", "Norte Chico", "Chan Chan", "Huaca del Sol",
        "Pukara", "Sican", "Quimbaya", "Tairona", "Marajoara", "Arawak Antiquity",
        "Taino Origins", "Mississippian Culture", "Cahokia", "Ancestral Puebloans", "Hohokam",
        "Mogollon", "Hopewell Tradition", "Adena Culture", "Haudenosaune Origins", "Chaco Canyon",
        "Mesa Verde", "Poverty Point", "Moundville", "Ancient Amazonia", "Guarani Origins",
        "Mapuche Origins", "Patagonia Ancient Landscapes", "Rapa Nui", "Caribbean Antiquity",
    )),
]


def _make_entry(name: str, year: int, era: str, group: str) -> dict[str, object]:
    return {
        "match": (name.lower(),),
        "location": name,
        "title": name,
        "year": year,
        "year_label": f"c. {abs(year)} {'BCE' if year < 0 else 'CE'}",
        "era": era,
        "kind": "historical",
        "prompt_context": f"A source-aware journey through {name}, treated as a time-bounded {group.lower()} context rather than a modern national border.",
        "suggestions": [f"Explore {name} archaeology", "Ask what the evidence shows", "Compare neighboring societies"],
    }


_ALL_CATALOG = [
    _make_entry(name, year, era, group)
    for group, year, era, names in _GROUPS
    for name in names
]

# Keep the requested total exact while sampling each geographic group evenly.
# This avoids a long first region crowding out the Americas, Africa or Oceania.
ANCIENT_CATALOG_236: list[dict[str, object]] = []
for offset in range(max(len(names) for _, _, _, names in _GROUPS)):
    for group, year, era, names in _GROUPS:
        if offset < len(names):
            ANCIENT_CATALOG_236.append(_make_entry(names[offset], year, era, group))
            if len(ANCIENT_CATALOG_236) == 236:
                break
    if len(ANCIENT_CATALOG_236) == 236:
        break

assert len(ANCIENT_CATALOG_236) == 236, len(ANCIENT_CATALOG_236)
