# Chronoverse — implementation plan

## Maqsad
Chronoverse’ni Flask asosidagi professional time-travel museum MVP sifatida qurish: foydalanuvchi tabiiy tilda manzil tanlaydi, CHRONOS kontekstli javob beradi, tarixiy ishonchlilik darajasini ajratadi, cinematic journey animatsiyasi ishga tushadi va autentik media hamda AI reconstruction oqimlari alohida ko‘rsatiladi.

## Arxitektura
- `app.py`: Flask factory, JSON API route’lari, input validation, rate limiting va xavfsiz fayl serving.
- `services/time_engine.py`: yil/BCE/CE, joy, davr va kelajak so‘rovlarini normalized destination’ga aylantiradi.
- `services/history_service.py`: qisqa, tekshiriladigan knowledge cards; fakt, arxeologik dalil, reconstruction va speculation alohida belgilanadi.
- `services/ai_service.py`: CHRONOS va `gpt-image-1` uchun backend-only OpenAI-compatible adapter. Kalit bo‘lmasa offline educational fallback ishlaydi; soxta AI media qaytarilmaydi.
- `services/media_service.py`: Wikimedia Commons API va optional YouTube Data API adapterlari. API yo‘q bo‘lsa source-aware fallback linklar qaytariladi, scraping qilinmaydi.
- `templates/index.html`, `static/chronoverse.css`, `static/chronoverse.js`: responsive cinematic UI, journey overlay, chat, image state, media/video explorer va accessible controls.
- `tests/test_chronoverse.py`: Flask route, destination parsing, missing credentials, mocked media va caching testlari.

## Dizayn
**Tanlangan yo‘nalish: cinematic archival interface.** Qoramtir obsidian fon, amber/gold time-marker ranglari va electric cyan status ranglari muzey arxivi hamda futuristik observatoriya orasidagi kayfiyatni beradi. Layout markazlashgan oddiy grid emas: chapda CHRONOS komanda paneli, o‘ngda destination dossier, pastda media rails.

Core principles: (1) fakt va reconstruction hech qachon aralashmaydi, (2) har bir asynchronous state aniq ko‘rinadi, (3) journey cinematic bo‘lsa ham tez va keyboard-accessible qoladi, (4) optional provider yo‘qligi foydalanuvchi tajribasini buzmaydi.

Typography: system sans-serif + serif display headings; katta editorial headings, kichik uppercase metadata va qisqa line-length. Animation: 180–700ms transitionlar, reduced-motion media query, 3-2-1 countdown va subtle scanline/radial glow.

## Chegaralar va fallback’lar
- OpenAI API kaliti bo‘lmasa CHRONOS deterministic educational mode’da ishlaydi; image card provider unavailable holatini tushuntiradi.
- Wikimedia Commons live search authentic media uchun ishlatiladi; unavailable bo‘lsa broken image emas, source fallback card chiqadi.
- YouTube API faqat `YOUTUBE_API_KEY` bilan ishlaydi; aks holda YouTube’ning destination-specific search linki beriladi, video scrape qilinmaydi.
- AI image disk cache’lanadi va bir xil destination/scene uchun takroriy generation qilinmaydi.
- Video generation hozir provider interface/status panel sifatida qoldiriladi; fake video ko‘rsatilmaydi.

## Ishga tushirish
`python3 -m venv .venv && .venv/bin/pip install -r requirements.txt`, keyin `python3 app.py`. Development port Webdev runtime bilan 3000 qilib belgilanadi.
