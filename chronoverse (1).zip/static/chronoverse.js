const state = { destination: null, conversation: [], autoImage: true, mediaCategory: 'historical architecture', imageBusy: false };
const $ = (selector) => document.querySelector(selector);
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const escapeHTML = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));

function setStatus(message, tone = 'cyan') {
  const status = $('#system-status');
  status.innerHTML = `<span class="status-pulse"></span><span>${escapeHTML(message)}</span>`;
  status.style.color = tone === 'error' ? 'var(--red)' : tone === 'gold' ? 'var(--gold-bright)' : 'var(--cyan)';
}

function addMessage(role, content, evidence = '') {
  const log = $('#assistant-log');
  const item = document.createElement('div');
  item.className = `message ${role === 'user' ? 'user-message' : 'assistant-message'}`;
  item.innerHTML = role === 'user'
    ? `<div><span class="message-label">YOU / TRANSMISSION</span><p>${escapeHTML(content)}</p></div><div class="message-avatar">↗</div>`
    : `<div class="message-avatar">✦</div><div><span class="message-label">CHRONOS / ${escapeHTML(evidence || 'INTERPRETATION')}</span><p>${escapeHTML(content)}</p></div>`;
  log.appendChild(item);
  log.scrollTop = log.scrollHeight;
}

async function postJSON(url, body) {
  const response = await fetch(url, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.reason || `Request failed (${response.status})`);
  return data;
}

async function runJourney(destination) {
  const overlay = $('#journey-overlay');
  const count = $('#countdown');
  const label = $('#countdown-label');
  overlay.hidden = false;
  const sequence = [['03', 'CALIBRATING COORDINATES'], ['02', 'FOLDING THE DISTANCE'], ['01', 'OPENING THE TIME WINDOW']];
  for (const [number, text] of sequence) { count.textContent = number; label.textContent = text; await wait(480); }
  count.textContent = '✦'; label.textContent = `ARRIVED / ${destination.location.toUpperCase()}`;
  await wait(500); overlay.hidden = true;
}

function renderDestination(destination, context) {
  $('#destination-title').textContent = destination.title;
  $('#destination-year').textContent = destination.year_label;
  $('#destination-era').textContent = destination.era;
  $('#coordinate-readout').textContent = `${destination.location.toUpperCase()} / ${destination.kind.toUpperCase()}`;
  $('#stage-kind').textContent = destination.certainty.toUpperCase();
  $('#destination-intro').textContent = destination.prompt_context;
  $('#generate-image').disabled = false;
  $('#load-videos').disabled = false;
  $('#timeline').innerHTML = (context.timeline || []).map((item) => `<div class="timeline-item"><span>${escapeHTML(item.year)}</span><p>${escapeHTML(item.text)}</p></div>`).join('');
  $('#evidence-note').innerHTML = `<span class="note-symbol">◌</span><p>${escapeHTML(context.important_note)}</p>`;
  $('#fact-grid').innerHTML = (context.cards || []).map((card) => `<article class="fact-card"><span class="fact-tag">${escapeHTML(card.label)}</span><h3>${escapeHTML(card.title)}</h3><p>${escapeHTML(card.text)}</p></article>`).join('');
  $('#image-frame').dataset.destination = destination.key;
}

function renderImageLoading() {
  $('#image-frame').innerHTML = '<div class="image-loading"><div class="loader"></div><span>GENERATING EVIDENCE-AWARE RECONSTRUCTION</span></div>';
}

function renderImageError(reason) {
  $('#image-frame').innerHTML = `<div class="image-error"><strong>VISUAL PROVIDER UNAVAILABLE</strong><p>${escapeHTML(reason)}</p><p>Enable an OpenAI API key on the backend to create a reconstruction. Authentic archive search works independently.</p></div>`;
}

async function requestImage(scene = 'arrival panorama') {
  if (!state.destination || state.imageBusy) return;
  state.imageBusy = true;
  $('#generate-image').disabled = true;
  renderImageLoading();
  setStatus('Visual reconstruction request in progress…', 'gold');
  try {
    const result = await postJSON('/api/chronos/image', { destination: state.destination, scene });
    if (!result.ok) { renderImageError(result.reason || 'No image was created.'); setStatus('Arrival complete; visual provider is not configured.', 'gold'); return; }
    const imageKind = result.archive ? 'Authentic archive photograph' : result.offline ? 'Offline artistic reconstruction' : 'AI reconstruction';
    const source = result.source_url ? `<a href="${escapeHTML(result.source_url)}" target="_blank" rel="noopener">SOURCE ↗</a>` : '';
    $('#image-frame').innerHTML = `<div class="image-result"><img src="${escapeHTML(result.image_url)}" alt="${imageKind} of ${escapeHTML(state.destination.title)}" loading="lazy"><span class="image-label">${escapeHTML(result.label)} ${source}</span></div>`;
    setStatus(result.archive ? 'Authentic archive image loaded from Wikimedia Commons.' : result.offline ? 'Offline reconstruction loaded — no API credits used.' : result.cached ? 'Cached reconstruction loaded.' : 'Arrival reconstruction ready.', 'cyan');
  } catch (error) { renderImageError(error.message); setStatus(error.message, 'error'); }
  finally { state.imageBusy = false; $('#generate-image').disabled = false; }
}

function renderMedia(data) {
  const grid = $('#media-grid');
  if (!data.items || !data.items.length) {
    const fallback = data.search_url ? `<a class="media-link" target="_blank" rel="noopener" href="${escapeHTML(data.search_url)}">OPEN OFFICIAL SEARCH ↗</a>` : '';
    grid.innerHTML = `<div class="media-empty"><span class="empty-icon">⌁</span><h3>Authentic archive results are unavailable right now.</h3><p>${escapeHTML(data.message || 'No verified media matched this destination.')}</p>${fallback}</div>`;
    return;
  }
  grid.innerHTML = data.items.map((item) => `<article class="media-card"><div class="media-card-image"><img src="${escapeHTML(item.preview)}" alt="${escapeHTML(item.title)}" loading="lazy" onerror="this.closest('.media-card').querySelector('.media-card-image').innerHTML='<div class=\'media-empty\'>Preview unavailable</div>'"></div><div class="media-card-body"><h3 title="${escapeHTML(item.title)}">${escapeHTML(item.title)}</h3><div class="media-meta">${escapeHTML(item.source)} · ${escapeHTML(item.date)}</div><div class="media-meta">${escapeHTML(item.creator)}</div><a class="media-link" href="${escapeHTML(item.original)}" target="_blank" rel="noopener">SOURCE & LICENSE ↗</a></div></article>`).join('');
}

async function loadMedia(category = state.mediaCategory) {
  if (!state.destination) return;
  state.mediaCategory = category;
  $('#media-grid').innerHTML = '<div class="media-empty"><div class="loader" style="margin:auto"></div><p>Searching the open archive…</p></div>';
  try { renderMedia(await postJSON('/api/media', {destination: state.destination, category})); }
  catch (error) { renderMedia({message: error.message}); }
}

function renderVideos(data) {
  const grid = $('#video-grid');
  if (!data.items || !data.items.length) {
    const link = data.search_url ? `<a class="media-link" target="_blank" rel="noopener" href="${escapeHTML(data.search_url)}">OPEN OFFICIAL YOUTUBE SEARCH ↗</a>` : '';
    grid.innerHTML = `<div class="video-empty">${escapeHTML(data.message || 'No verified videos found for this destination.')} ${link}</div>`;
    return;
  }
  grid.innerHTML = data.items.map((item) => `<article class="video-card"><h4>${escapeHTML(item.title)}</h4><p>${escapeHTML(item.channel)} · ${escapeHTML(item.published)}</p><a href="${escapeHTML(item.url)}" target="_blank" rel="noopener">WATCH ON YOUTUBE ↗</a></article>`).join('');
}

async function loadVideos() {
  if (!state.destination) return;
  $('#video-grid').innerHTML = '<div class="video-empty">Finding relevant documentary signals…</div>';
  try { renderVideos(await postJSON('/api/videos', {destination: state.destination})); }
  catch (error) { renderVideos({message: error.message}); }
}

async function submitJourney(event) {
  event.preventDefault();
  const input = $('#journey-input');
  const message = input.value.trim();
  if (!message) { setStatus('Enter a destination or question first.', 'error'); input.focus(); return; }
  const button = $('#journey-submit');
  button.disabled = true; setStatus('CHRONOS is interpreting your coordinates…', 'gold'); addMessage('user', message); input.value = ''; $('#char-count').textContent = '0 / 2000';
  try {
    const result = await postJSON('/api/chronos', {message, destination: state.destination, conversation: state.conversation, auto_image: state.autoImage});
    const changed = !state.destination || state.destination.key !== result.destination.key;
    state.destination = result.destination; state.conversation.push({role: 'user', content: message});
    if (changed && result.journey) await runJourney(state.destination);
    renderDestination(state.destination, result.context);
    state.conversation.push({role: 'assistant', content: result.answer.reply});
    addMessage('assistant', result.answer.reply, result.answer.evidence);
    if (changed) { $('#reconstruction').scrollIntoView({behavior: 'smooth', block: 'center'}); await loadMedia(); }
    if (result.should_generate_image && state.autoImage && changed) await requestImage();
    const providerError = result.answer.provider_error;
    const offlineStatus = providerError?.category === 'quota_or_rate_limit'
      ? 'Educational offline mode active — local reconstruction available; no API credits used.'
      : providerError?.category === 'authentication' || providerError?.category === 'permission'
        ? 'Educational offline mode active — local reconstruction available; AI key needs attention.'
        : 'Educational offline mode active — local reconstruction available.';
    setStatus(result.answer.mode === 'ai' ? 'CHRONOS AI connection active.' : offlineStatus, result.answer.mode === 'ai' ? 'cyan' : 'gold');
  } catch (error) { addMessage('assistant', error.message, 'SYSTEM'); setStatus(error.message, 'error'); }
  finally { button.disabled = false; }
}

$('#journey-form').addEventListener('submit', submitJourney);
$('#journey-input').addEventListener('input', (event) => { $('#char-count').textContent = `${event.target.value.length} / 2000`; });
$('#auto-image').addEventListener('change', (event) => { state.autoImage = event.target.checked; setStatus(state.autoImage ? 'Automatic reconstruction enabled.' : 'Automatic reconstruction paused.', state.autoImage ? 'cyan' : 'gold'); });
$('#generate-image').addEventListener('click', () => requestImage('cinematic arrival panorama'));
$('#load-videos').addEventListener('click', loadVideos);
document.querySelectorAll('.example-chip').forEach((chip) => chip.addEventListener('click', () => { $('#journey-input').value = chip.dataset.prompt; $('#journey-input').dispatchEvent(new Event('input')); $('#journey-input').focus(); }));
document.querySelectorAll('.gallery-tab').forEach((tab) => tab.addEventListener('click', () => { document.querySelectorAll('.gallery-tab').forEach((item) => item.classList.remove('active')); tab.classList.add('active'); loadMedia(tab.dataset.category); }));
